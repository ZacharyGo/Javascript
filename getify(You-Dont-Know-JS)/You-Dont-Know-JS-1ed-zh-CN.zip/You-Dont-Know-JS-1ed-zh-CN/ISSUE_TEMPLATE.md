**Yes, I promise I've read the [Contributions Guidelines](CONTRIBUTING.md)** (please feel free to remove this line).
