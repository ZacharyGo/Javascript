# 你不懂JS：ES6与未来

<img src="cover.jpg" width="300">

-----

**[从 O'Reilly 购买数字/印刷版](http://shop.oreilly.com/product/0636920033769.do)**

-----

[目录](toc.md)

* [序](foreword.md)（[Rick Waldron](http://bocoup.com/weblog/author/rick-waldron/)）
* [前言](../preface.md)
* [第一章：ES？现在与未来](ch1.md)
* [第二章：语法](ch2.md)
* [第三章：组织](ch3.md)
* [第四章：异步流程控制](ch4.md)
* [第五章：集合](ch5.md)
* [第六章：新增 API](ch6.md)
* [第七章：元编程](ch7.md)
* [第八章：ES6 之后](ch8.md)
* [附录A：鸣谢](apA.md)
 