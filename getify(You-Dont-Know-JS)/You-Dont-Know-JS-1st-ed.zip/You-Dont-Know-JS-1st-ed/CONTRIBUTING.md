# Contributing

I am not accepting any contributions to the 1st edition books. Please check out [the 2nd edition](https://github.com/getify/You-Dont-Know-JS/tree/2nd-ed).
