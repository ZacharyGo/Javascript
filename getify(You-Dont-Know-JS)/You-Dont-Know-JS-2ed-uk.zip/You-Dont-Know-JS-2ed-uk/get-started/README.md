# Серія "Ти поки що не знаєш JS". Книга 1: "Перші кроки". Друге видання

<img src="images/cover.png" width="300">

-----

**[Купити ebook чи PDF на Leanpub](https://leanpub.com/ydkjsy-get-started)**

-----

[Зміст](toc.md)

* [Передмова](foreword.md) (від [Брайана Голта](https://twitter.com/holtbt))
* [Вступ](../preface.md)
* [Глава 1: Що таке JavaScript?](ch1.md)
* [Глава 2: Огляд JS](ch2.md)
* [Глава 3: Шлях до самого коріння JS](ch3.md)
* [Глава 4: Загальна картина мови](ch4.md)
* [Додаток A: Продовжуємо дослідження](apA.md)
* [Додаток B: Прийшов час практики!](apB.md)
